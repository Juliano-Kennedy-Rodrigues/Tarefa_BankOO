public class ContaCorrente{

    public string Nome { get; set; }
    public int Agencia { get; set; }
    public double _saldo { get; set; }

    public double Saldo { 
        get 
        {
            return this._saldo;
        }
        set
        {
            if(value >= 0)
            {
                this._saldo = value;
            }
        } 
    }

     public string CPF { get; set; }

    //Saldo
    public int Conta { get; set; }
    public static int TotaldeContasCriadas { get; set; }

    public bool Sacar(double valor){
        if(this.Saldo < valor)
        {
            return false;
        }
        else
        {
            this.Saldo -= valor;
            return true;
        }
    }

    public void Depositar(double valor){
        this.Saldo += valor;
    }

    public bool Transferir(double valor, ContaCorrente ContaDestino){
        if(this.Saldo < valor)
        {
            return false;
        }
        else
        {
            this.Sacar(valor);
            ContaDestino.Depositar(valor);
            return true;
        }
    }

    public ContaCorrente(){}

    public ContaCorrente(string nome, double saldo, int conta, Funcionario funcionario){

        	this.Nome = nome;
            this.Saldo = saldo;
			this.Conta = conta;

			TotaldeContasCriadas ++;
    }

}

/*
DEVE TER:

NOME
CPF
SALDO
NÚMERO DA CONTA

PODE FAZER:

SACAR
DEPOSITAR
TRANSFERIR
*/