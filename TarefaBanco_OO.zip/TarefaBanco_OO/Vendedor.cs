public class Vendedor : Funcionario{
    public int ContasCriadas { get; set; }

    public override double Bonificacao{ 
        get
        {
            return _bonificacao;
        }
        set
        {
            _bonificacao += value * 0.02;
        }  
    }

    public override int Ferias(){ 
        var diasDeFerias = 30 + ContasCriadas * 1;
        return diasDeFerias;
    }
    
}