﻿using System;

namespace TarefaBanco_OO
{
    class Program
    {
        static void Main(string[] args)
        {
            Vendedor vendedorMaria = new Vendedor(){
                CPF = "123.456.789-00",
                Nome = "Maria",
                Salario = 1000,
                ContasCriadas = 1, //criou uma conta 123
            };

            vendedorMaria.Bonificacao = vendedorMaria.Salario;
            Console.WriteLine("Nome: " +vendedorMaria.Nome+"\n"+"CPF: "+vendedorMaria.CPF+"\n"+"Salário: "+vendedorMaria.Salario);
            Console.WriteLine("Bonificação do vendedor "+vendedorMaria.Nome+": "+vendedorMaria.Bonificacao);
            Console.WriteLine("Férias do vendedor "+vendedorMaria.Nome+": "+vendedorMaria.Ferias()+" dias");
            Console.WriteLine("Remuneração Anual do vendedor "+vendedorMaria.Nome+": "+vendedorMaria.RemuneracaoAnual(vendedorMaria.Salario, vendedorMaria.Bonificacao));
            Console.WriteLine("---------------------------------------");

            ContaCorrente contaDoLeo = new ContaCorrente("Leonardo", 100, 1234, vendedorMaria);

            Console.WriteLine("Salado do Leo: " +contaDoLeo.Saldo);
            contaDoLeo.Sacar(10);
            Console.WriteLine("Conta do Leo após sacar 10 reais: "+ contaDoLeo.Saldo);
            Console.WriteLine("---------------------------------------");

            Vendedor vendedorPaloma = new Vendedor(){
                CPF = "987.654.321-00",
                Nome = "Paloma",
                Salario = 1000,
                ContasCriadas = 1, //criou uma conta 234
            };

            vendedorPaloma.Bonificacao = vendedorPaloma.Salario;
            Console.WriteLine("Nome: " +vendedorPaloma.Nome+"\n"+"CPF: "+vendedorPaloma.CPF+"\n"+"Salário: "+vendedorPaloma.Salario);
            Console.WriteLine("Bonificação do vendedor "+vendedorPaloma.Nome+": "+vendedorPaloma.Bonificacao);
            Console.WriteLine("Férias do vendedor "+vendedorPaloma.Nome+": "+vendedorPaloma.Ferias()+" dias");
            Console.WriteLine("Remuneração Anual do vendedor "+vendedorPaloma.Nome+": "+vendedorPaloma.RemuneracaoAnual(vendedorPaloma.Salario, vendedorPaloma.Bonificacao));
            Console.WriteLine("---------------------------------------");

            ContaCorrente contaDaPoliane = new ContaCorrente("Poliane", 200, 1234, vendedorPaloma);
            
            Console.WriteLine("Saldo da Poliane: "+ contaDaPoliane.Saldo);
            contaDaPoliane.Depositar(20);
            Console.WriteLine("Saldo após depositar 20 reais da conta da Poliane: "+ contaDaPoliane.Saldo);
            Console.WriteLine("---------------------------------------");


            Vendedor vendedorVicente = new Vendedor(){
                CPF = "567.123.789-00",
                Nome = "Vicente",
                Salario = 1000,
                ContasCriadas = 1, // criou uma conta 345
            };

            vendedorVicente.Bonificacao = vendedorVicente.Salario;
            Console.WriteLine("Nome: " +vendedorVicente.Nome+"\n"+"CPF: "+vendedorVicente.CPF+"\n"+"Salário: "+vendedorVicente.Salario);
            Console.WriteLine("Bonificação do vendedor "+vendedorVicente.Nome+": "+vendedorVicente.Bonificacao);
            Console.WriteLine("Férias do vendedor "+vendedorVicente.Nome+": "+vendedorVicente.Ferias()+" dias");
            Console.WriteLine("Remuneração Anual do vendedor "+vendedorVicente.Nome+": "+vendedorVicente.RemuneracaoAnual(vendedorVicente.Salario, vendedorVicente.Bonificacao));
            Console.WriteLine("---------------------------------------");

            ContaCorrente contaDoJuliano = new ContaCorrente("Juliano Rodrigues", 50, 1234, vendedorVicente);

            Console.WriteLine("Saldo do Juliano: "+ contaDoJuliano.Saldo +" e saldo da Poliane: "+ contaDaPoliane.Saldo);
            contaDaPoliane.Transferir(20,contaDoJuliano);
            Console.WriteLine("Saldo do Juliao após tranferência de 20 reais da conta da Poliane: "+ contaDoJuliano.Saldo);
            Console.WriteLine("Saldo da Poliane após tranferência de 20 reais para conta do Juliano: "+ contaDaPoliane.Saldo);
            Console.WriteLine("---------------------------------------");
            

            Gerente gerenteJonas = new Gerente(){
                CPF = "345.871.923-15",
                Nome = "Jonas",
                Salario = 2000,
                NumeroDeAgencias = 3, //as três agências
            };

            gerenteJonas.Bonificacao = gerenteJonas.Salario;
            Console.WriteLine("Nome: " +gerenteJonas.Nome+"\n"+"CPF: "+gerenteJonas.CPF+"\n"+"Salário: "+gerenteJonas.Salario);
            Console.WriteLine("Bonificação do gerente "+gerenteJonas.Nome+": "+gerenteJonas.Bonificacao);
            Console.WriteLine("Férias do gerente "+gerenteJonas.Nome+": "+gerenteJonas.Ferias()+" dias");
            Console.WriteLine("Remuneração Anual do gerente "+gerenteJonas.Nome+": "+gerenteJonas.RemuneracaoAnual(gerenteJonas.Salario, gerenteJonas.Bonificacao));
            Console.WriteLine("---------------------------------------");

            Console.WriteLine("\nNúmero de contas criadas: "+ContaCorrente.TotaldeContasCriadas);
        }
    }
}
